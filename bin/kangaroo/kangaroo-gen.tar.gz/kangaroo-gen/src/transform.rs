use rand::Rng;
use rand::seq::SliceRandom;

/// A simple bijective transformation on a byte array
#[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)]
pub enum SimpleTransform {
    /// Cycles the bytes in the array forwards (right) by some amount
    Cycle(u8),
    /// Cycles each group of this many bytes forwards (right) by 1
    Subcycle(u8),
    /// Adds some value to every byte in the array, wrapping at 256
    WrapAdd(u8),
    /// XORs every byte in the array with some value
    Xor(u8),
}

/// A bijective transformation on a byte array,
/// made up of 1 or 2 simple transformations
#[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)]
pub enum Transformation {
    /// A single simple transformation
    Simple(SimpleTransform),
    /// One simple transformation followed by another
    Seq(SimpleTransform, SimpleTransform),
}

impl SimpleTransform {
    /// Randomly generate a simple transformation;
    /// the enum branch to take is specified by `choice`,
    /// so you can manually choose which type of transformation to generate
    pub fn gen<R: Rng>(rng: &mut R, choice: u8) -> Self {
        match choice {
            0 => Self::Cycle(rng.gen_range(1..8)),
            1 => Self::Subcycle(rng.gen_range(2..5)),
            2 => Self::WrapAdd(rng.gen_range(1..=255)),
            3 => Self::Xor(rng.gen_range(1..=255)),
            _ => panic!("Invalid type of transformation"),
        }
    }

    /// Apply this transformation to a byte array
    pub fn apply(&self, data: &mut [u8]) {
        match *self {
            Self::Cycle(l) => {
                // Cycle the array `l` times
                for _ in 0..l {
                    cycle(data);
                }
            },
            Self::Subcycle(l) => {
                // Cycle each block of `l` bytes once
                for b in (0..data.len()).step_by(l as usize) {
                    let end = data.len().min(b + (l as usize));
                    cycle(&mut data[b..end]);
                }
            },
            Self::WrapAdd(n) => {
                // Wrapping add `n` to every byte
                for v in data.iter_mut() {
                    *v = v.wrapping_add(n);
                }
            },
            Self::Xor(n) => {
                // XOR `n` with every byte
                for v in data.iter_mut() {
                    *v ^= n;
                }
            },
        }
    }

    /// Generate the C code used to apply this transformation
    pub fn codegen(&self) -> String {
        match *self {
            Self::Cycle(l) => format!("docycle({})", l),
            Self::Subcycle(l) => format!("dosubcycle({})", l),
            Self::WrapAdd(n) => format!("dowrapadd({})", n),
            Self::Xor(n) => format!("doxor({})", n),
        }
    }
}

impl Transformation {
    /// Randomly generate an array of 8 transformations.
    /// The first 4 are each of the branches of `SimpleTransform`,
    /// and the last 4 are `Seq`s of 2 distinct variants of simple transformations.
    pub fn gen_all<R: Rng>(rng: &mut R) -> [Self; 8] {[
        Self::Simple(SimpleTransform::gen(rng, 0)),
        Self::Simple(SimpleTransform::gen(rng, 1)),
        Self::Simple(SimpleTransform::gen(rng, 2)),
        Self::Simple(SimpleTransform::gen(rng, 3)),
        Self::gen_seq(rng),
        Self::gen_seq(rng),
        Self::gen_seq(rng),
        Self::gen_seq(rng),
    ]}

    /// Apply this transformation to a byte array
    pub fn apply(&self, data: &mut [u8]) {
        match self {
            Self::Simple(t) => t.apply(data),
            Self::Seq(t1, t2) => {
                t1.apply(data);
                t2.apply(data);
            },
        }
    }

    /// Generate the C code used to apply this transformation
    pub fn codegen(&self) -> String {
        match self {
            Self::Simple(t) => t.codegen(),
            Self::Seq(t1, t2) => format!("{} {}", t1.codegen(), t2.codegen()),
        }
    }

    /// Randomly generate a `Seq` of 2 distinct variants of simple transformation
    fn gen_seq<R: Rng>(rng: &mut R) -> Self {
        let choices: Vec<_> = [0, 1, 2, 3].choose_multiple(rng, 2).cloned().collect();
        let mut choices: Vec<_> = choices.into_iter().map(|c| SimpleTransform::gen(rng, c)).collect();
        let c1 = choices.pop().unwrap();
        let c2 = choices.pop().unwrap();
        Self::Seq(c1, c2)
    }
}

/// Helper for cycling some slice of bytes forward once
fn cycle<T>(data: &mut [T]) {
    for i in 1..data.len() {
        data.swap(0, i);
    }
}
