#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <setjmp.h>

#define decl_globals(num_states) \
    jmp_buf start, control, accept, reject, transforms[8], states[num_states]; \
    int nxstate = 0, flag_len, transform_inds[] = {0, 1, 2, 3, 4, 5, 6, 7}; \
    unsigned char *flag;

#define mkjmp(jb) if (setjmp(jb))
#define ljmp(jb) longjmp(jb, 1)

#define statejmp(i) \
    mkjmp(states[i]) { \
        nxstate = jumps[i][*flag]; \
        permute(transform_inds, perms[i]); \
        ljmp(control); \
    } 

#define OPEN \
    mkjmp(start) { \
        puts("I sure am in a JUMPY mood today!!"); \
        puts("Let's see what you gave me to JUMP on!!"); \
        if (argc < 2) { \
            puts("Hey!! You didn't give me anything!!"); \
            return 1; \
        } \
        flag = (unsigned char *) strdup(argv[1]); \
        flag_len = strlen((char *) flag); \
        if (!flag_len) { \
            puts("Hey!! You didn't give me anything!!"); \
            return 1; \
        } \
        ljmp(states[nxstate]); \
    }

#define ACCEPT \
    mkjmp(accept) { \
        puts("Wow!! That was great!!"); \
        return 0; \
    }

#define REJECT \
    mkjmp(reject) { \
        puts("Hm, that wasn't very interesting..."); \
        return 0; \
    }

#define CONTROL \
    mkjmp(control) { \
        flag++; \
        flag_len--; \
        if (!flag_len) { \
            if (accepts[nxstate]) ljmp(accept); \
            ljmp(reject); \
        } \
        ljmp(transforms[transform_inds[0]]); \
    }

#define docycle(l) \
    for (int i = 0; i < l; i++) { \
        cycle(flag, flag_len); \
    }

#define dosubcycle(l) \
    for (int i = 0; i < flag_len; i += l) { \
        int len = l; \
        if (flag_len - i < len) len = flag_len - i; \
        cycle(flag + i, len); \
    }

#define dowrapadd(n) \
    for (int i = 0; i < flag_len; i++) { \
        flag[i] = (unsigned char) ((((unsigned int) flag[i]) + n) & 0xFF); \
    }

#define doxor(n) \
    for (int i = 0; i < flag_len; i++) { \
        flag[i] ^= n; \
    }

void permute(int arr[8], int8_t perm[8]) {
    for (int i = 0; i < 8; i++) {
        int j = i;

        while (perm[j] >= 0) {
            int swp = arr[i];
            arr[i] = arr[perm[j]];
            arr[perm[j]] = swp;

            int temp = perm[j];
            perm[j] -= 8;
            j = temp;
        }
    }

    for (int i = 0; i < 8; i++) {
        perm[i] += 8;
    }
}

static inline __attribute__((always_inline)) void cycle(unsigned char *arr, int n) {
    for (int i = 1; i < n; i++) {
        int tmp = arr[0];
        arr[0] = arr[i];
        arr[i] = tmp;
    }
}

