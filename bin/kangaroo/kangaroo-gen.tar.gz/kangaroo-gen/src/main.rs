mod jumpstate;
mod transform;
mod codegen;

use std::io::prelude::*;
use std::io::stdout;
use std::path::PathBuf;
use std::fs::File;

use structopt::StructOpt;

use rand::prelude::*;
use rand_chacha::ChaCha20Rng;
use rand_seeder::Seeder;

use jumpstate::*;
use transform::*;
use codegen::*;

/// Source code generator for Kangaroo CTF challenge
#[derive(Clone, Eq, PartialEq, Hash, Debug, StructOpt)]
#[structopt(name = "kangaroo-gen")]
struct Opts {
    /// The flag for the challenge
    #[structopt(short, long)]
    flag: String,

    /// The seed for the random number generator; uses a random seed if not specified
    #[structopt(short, long)]
    seed: Option<String>,

    /// The output file to write source code to; uses stdout if not specified
    #[structopt(short, long, parse(from_os_str))]
    outfile: Option<PathBuf>,

    /// Total number of states in the generated code
    #[structopt(short = "S", long, default_value = "128")]
    states: u32,
}

fn main() {
    let opts = Opts::from_args();

    let mut rng = opts.seed.as_deref()
        .map_or(ChaCha20Rng::from_entropy(), |s| Seeder::from(s).make_rng());

    let transforms = Transformation::gen_all(&mut rng);
    let jump_states = JumpState::gen_all(&mut rng, opts.states, &opts.flag, transforms);

    let mut writer: Box<dyn Write> = opts.outfile.as_deref()
        .map_or(Box::new(stdout()), |f| Box::new(File::create(f).expect("Error creating output file")));

    gen_file(&mut rng, &mut writer, &transforms, &jump_states).expect("Error writing output");
}
