use std::io::prelude::*;

use rand::Rng;
use rand::seq::SliceRandom;

use crate::jumpstate::*;
use crate::transform::*;

/// Generate source file, written to the given writer
pub fn gen_file<R: Rng, W: Write>(rng: &mut R, out: &mut W, transforms: &[Transformation; 8], states: &[JumpState]) -> std::io::Result<()> {
    // Copy the template to the output
    out.write_all(include_bytes!("template.c"))?;

    // Write the jump table
    out.write_all(b"int jumps[][256] = {\n")?;
    for s in states {
        out.write_all(b"    {")?;
        for j in s.jumps {
            write!(out, "{}, ", j)?;
        }
        out.write_all(b"},\n")?;
    }
    out.write_all(b"};\n\n")?;

    // Write the permutations
    out.write_all(b"int8_t perms[][8] = {\n")?;
    for s in states {
        out.write_all(b"    {")?;
        for p in s.permutation {
            write!(out, "{}, ", p)?;
        }
        out.write_all(b"},\n")?;
    }
    out.write_all(b"};\n\n")?;

    // Write the accepts array
    out.write_all(b"bool accepts[] = {\n")?;
    for s in states {
        writeln!(out, "    {},", s.accept)?;
    }
    out.write_all(b"};\n\n")?;

    // Declare the other globals
    writeln!(out, "decl_globals({})\n", states.len())?;

    // Main function header
    out.write_all(b"int main(int argc, char **argv) {\n")?;

    // Randomly shuffle all of the different jump blocks
    let mut blocks: Vec<String> = (0..states.len())
        .map(|x| format!("statejmp({})", x))
        .chain(transforms.iter().enumerate()
            .map(|(i, x)| format!("mkjmp(transforms[{}]) {{ {} ljmp(states[nxstate]); }}", i, x.codegen())))
        .chain(["OPEN", "CONTROL", "ACCEPT", "REJECT"].map(String::from))
        .collect();
    blocks.shuffle(rng);

    for b in blocks {
        writeln!(out, "    {}", b)?;
    }

    out.write_all(b"    ljmp(start);\n")?;

    // End of main function
    out.write_all(b"}\n")?;

    Ok(())
}
