use std::collections::HashSet;

use rand::Rng;
use rand::seq::SliceRandom;
use rand::distributions::{Distribution, Uniform};

use crate::transform::*;

/// A single jump state; permutes the array of transformations,
/// then jumps to the first transformation followed by another jump state,
/// depending on the current character
#[derive(Copy, Clone, Eq, PartialEq, Hash, Debug)]
pub struct JumpState {
    /// The next state to jump to
    pub jumps: [u32; 256],
    /// The permutation to apply to the transformations array;
    /// represented as a permutation of the numbers 0..8,
    /// where the number at each index represents the location this permutation sends the element there
    pub permutation: [i8; 8],
    /// Whether or not the string should be accepted if this is the last state
    pub accept: bool,
}

impl JumpState {
    /// Generate a list of jump states,
    /// such that exactly one path through them corresponds to the given flag
    pub fn gen_all<R: Rng>(rng: &mut R, num_states: u32, flag: &str, mut transforms: [Transformation; 8]) -> Vec<JumpState> {
        // Turn the flag into a mutable array of bytes
        let mut flag = flag.to_owned().into_bytes();

        // Number of states that will be part of the intended route
        // Equal to the length of the flag plus one for the final accept state
        let num_route_states = flag.len() as u32 + 1;

        // Total number of states should be more than the amount we have in our route
        assert!(num_states > num_route_states);

        // Number of states other than the ones in the route
        let num_other_states = num_states - num_route_states;

        // Number of "fail" states, which can be reached from the route states if a character is
        // incorrect, and which can only go to other failure states (including the final one)
        let num_fail_states = rng.gen_range(1.max(num_other_states/3)..num_other_states*2/3);

        // Each element in this list is the "id" or "number" of a state.
        // The order of the elements in this list is used to determine which states are which;
        // first are the route states (in order of the route), then the fail states,
        // then the unreachable states.
        // The first state is always 0, meaning it is always the first state in the route.
        let mut states: Vec<u32> = (0..num_states).collect();
        states[1..].shuffle(rng);

        // We make a `HashSet` of all the reachable state numbers so we can quickly check if a
        // state is reachable
        let num_reachable_states = num_route_states + num_fail_states;
        let mut reachable_states: HashSet<u32> = HashSet::with_capacity(num_reachable_states as usize);
        reachable_states.extend(&states[..num_reachable_states as usize]);

        // This is the list we return; the index of a state in this list is its number
        let mut jump_states: Vec<_> = (0..num_states).map(|state_num| {
            let mut state = JumpState {
                jumps: [0; 256],
                permutation: [0; 8],
                accept: false,
            };

            // Generate a random permutation
            let mut perm: Vec<_> = (0..8).collect();
            perm.shuffle(rng);
            state.permutation.copy_from_slice(&perm);

            let reachable = reachable_states.contains(&state_num);

            // Since we use the same range for all of the jumps,
            // it's more efficient to make a distribution and reuse it
            let jump_dist = Uniform::from(if reachable {
                // For reachable states, all of the possible destinations should be failure states.
                // The route states will be edited later to have actual jumps to the next state in
                // the route.
                num_route_states..num_reachable_states
            } else {
                // Unreachable states are unreachable, so they can jump anywhere
                0..num_states
            });

            // Put a random state generated from the above distribution in each jump
            for slot in state.jumps.iter_mut() {
                *slot = states[jump_dist.sample(rng) as usize];
            }

            // Unreachable states can be accept states
            if !reachable {
                state.accept = rng.gen_ratio(1, 5);
            }

            state
        }).collect();

        // In order to fill in the jumps in the correct route,
        // we simulate what happens when we give the flag as input,
        // and adjust the jump that gets taken at each step to follow the route
        for i in 0..flag.len() {
            // Get the ith route state
            let state = &mut jump_states[states[i] as usize];

            // Set the jump taken from this state to the next route state
            state.jumps[flag[i] as usize] = states[i+1];

            // Apply this state's permutation to the transformation array
            apply_perm(state.permutation, &mut transforms);

            // Apply the first transformation to the remaining part of the flag
            transforms[0].apply(&mut flag[i+1..]);
        }

        // The final route state should be an accept state
        jump_states[states[flag.len()] as usize].accept = true;

        jump_states
    }
}

/// Helper function for applying a permutation to an array
fn apply_perm<T>(mut perm: [i8; 8], arr: &mut [T; 8]) {
    for i in 0..8 {
        let mut j = i;

        while perm[j] >= 0 {
            let tmp = perm[j] as usize;
            arr.swap(i, tmp);
            perm[j] -= 8;
            j = tmp;
        }
    }
}
